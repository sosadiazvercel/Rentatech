'use client';

import {type FormEvent,useEffect,useMemo,useRef,useState} from 'react';
import Image from 'next/image';
import Link from 'next/link';
import {useRouter} from 'next/navigation';
import {Headset} from './headset';
import type {PublicProduct} from '@/server/public-products';

export function SiteHeader({products}:{products:PublicProduct[]}){
 const [open,setOpen]=useState(false),[searchOpen,setSearchOpen]=useState(false),[query,setQuery]=useState('');
 const inputRef=useRef<HTMLInputElement>(null);
 const router=useRouter();
 const close=()=>{setOpen(false);setSearchOpen(false);};
 const openSearch=()=>{setOpen(false);setSearchOpen(true);};
 const results=useMemo(()=>{
  const q=query.trim().toLowerCase();
  if(!q)return products;
  return products.filter(p=>(p.title+' '+p.category+' '+p.meta+' '+p.code).toLowerCase().includes(q));
 },[products,query]);
 useEffect(()=>{if(searchOpen)inputRef.current?.focus();},[searchOpen]);
 function submitSearch(e:FormEvent){
  e.preventDefault();
  const target=results[0]?.href??'/vr';
  close();
  router.push(target);
 }
 return <header className="header">
  <div className="wrap header-inner">
   <Link className="brand" href="/" onClick={close}>RENTA TECH<small>by SosaDiaz</small></Link>
   <div className="mobile-actions" aria-label="Acciones rapidas">
    <Link className="mobile-icon mobile-phone" href="/cotizar?contacto=telefono" aria-label="Telefono"><span/></Link>
    <button className="mobile-icon mobile-search" type="button" aria-label="Buscar" aria-expanded={searchOpen} onClick={openSearch}><span/></button>
    <Link className="button black" href="/cotizar">Cotizar</Link>
    <button className="menu-toggle mobile-icon mobile-burger" type="button" aria-label="Abrir menu" aria-expanded={open} onClick={()=>setOpen(!open)}><span/></button>
   </div>
   <nav className="nav" aria-label="Navegacion principal">
    <div className="nav-mega-item">
     <Link className="nav-mega-trigger" href="/vr" aria-haspopup="true">Realidad Virtual</Link>
     <div className="mega-menu" role="group" aria-label="Productos de realidad virtual">
      <div className="mega-inner">
       <div className="mega-browse">
        <p>Explorar</p>
        <Link href="/vr">Todos</Link>
        {products.map(p=><Link key={p.code} href={p.href}>{p.title}</Link>)}
       </div>
       <div className="mega-featured">
        <p>Destacados</p>
        <div className="mega-products">
         {products.map(p=><Link className="mega-product" href={p.href} key={p.code}>
          <span className="product-image-frame"><Headset model={p.code}/></span>
          <strong>{p.title}</strong>
          <small>{p.meta}</small>
          <span>{p.price} / dia</span>
         </Link>)}
        </div>
       </div>
       <div className="mega-copy">
        <p>Realidad virtual</p>
        <span>Equipos Meta Quest probados y listos para eventos, activaciones y experiencias inmersivas.</span>
        <Link href="/cotizar">Solicitar una cotizacion {'->'}</Link>
        <Link href="/vr">Ver todos los equipos {'->'}</Link>
       </div>
      </div>
     </div>
    </div>
    <button className="desktop search-trigger" type="button" aria-expanded={searchOpen} onClick={openSearch}>Buscar</button>
    <Link className="button black" href="/cotizar">Solicitar cotizacion</Link>
   </nav>
  </div>
  <div className={`site-search ${searchOpen?'open':''}`} role="search">
   <form className="site-search-bar" onSubmit={submitSearch}>
    <span className="mobile-search" aria-hidden="true"><span/></span>
    <input ref={inputRef} value={query} onChange={e=>setQuery(e.target.value)} onKeyDown={e=>{if(e.key==='Escape'){setSearchOpen(false);setQuery('');}}} placeholder="Buscar producto" aria-label="Buscar producto" autoComplete="off"/>
    <button type="button" onClick={()=>{setSearchOpen(false);setQuery('');}}>Esc</button>
   </form>
   <div className="site-search-results" aria-label="Resultados de busqueda">
    {results.length?results.map(p=><Link key={p.href} href={p.href} onClick={close}>
     <span className="search-thumb"><Image src={p.image} alt="" width={96} height={72}/></span>
     <strong>{p.title}</strong>
     <span>{p.category}</span>
     <em>{p.price} <small>/ dia</small></em>
    </Link>):<div className="site-search-empty">No encontramos productos con ese nombre.</div>}
   </div>
  </div>
  <div className={`mobile-menu ${open?'open':''}`}>
   <nav aria-label="Menu movil">
    <Link href="/vr" onClick={close}>Realidad virtual <span>v</span></Link>
    {products.map(p=><Link href={p.href} onClick={close} key={p.code}>{p.title} <span>v</span></Link>)}
    <Link href="/cotizar" onClick={close}>Cotizar <span>v</span></Link>
   </nav>
   <div className="mobile-portal">
    <Link href="/admin" onClick={close}>Portal cliente <span>-&gt;</span></Link>
    <div>
     <strong>Prepara tu evento</strong>
     <p>Cuentanos fecha, ciudad y cantidad de visores. Revisamos disponibilidad antes de confirmar.</p>
     <Link className="button light compact" href="/cotizar" onClick={close}>Solicitar cotizacion</Link>
    </div>
   </div>
   <div className="mobile-meta">
    <Link href="/cotizar?contacto=telefono" onClick={close}>tel RENTATECH</Link>
    <Link href="/cotizar" onClick={close}>Kit list 0</Link>
   </div>
  </div>
 </header>;
}
