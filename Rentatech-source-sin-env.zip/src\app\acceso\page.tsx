import {LoginForm} from '@/components/login-form';

export default function Login(){return <div className="wrap"><section className="card login-card"><div className="eyebrow">Espacio del equipo</div><h1>Todo empieza con una conversacion.</h1><p>Accede para revisar solicitudes, cotizaciones, reservas y operaciones.</p><LoginForm/><p style={{fontSize:11,margin:'20px 0 0'}}>Acceso exclusivo para el equipo autorizado de RENTATECH.</p></section></div>;}
