import {HomeHero} from '@/components/home-hero';
import {ProductCards} from '@/components/marketing';
import {getPublicProducts} from '@/server/public-products';

export const dynamic='force-dynamic';

export default async function Home() {
 const products=await getPublicProducts();
 return <div className="wrap">
  <HomeHero products={products}/>
  <section className="section">
   <div className="section-heading">
    <div>
     <p className="eyebrow">Nuestros equipos</p>
     <h2>Realidad Virtual</h2>
    </div>
    <p>Equipos de realidad virtual listos para crear experiencias memorables.</p>
   </div>
   <ProductCards products={products}/>
  </section>
 </div>;
}
