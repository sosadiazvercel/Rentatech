import {describe,it,expect,afterEach} from 'vitest';
import {makeLocalSession,readLocalSession} from '@/server/auth';
const previous={app:process.env.APP_ENV,mode:process.env.AUTH_MODE,secret:process.env.SESSION_SECRET};
afterEach(()=>{process.env.APP_ENV=previous.app;process.env.AUTH_MODE=previous.mode;process.env.SESSION_SECRET=previous.secret;});
describe('Local fixture session',()=>{
 it('rejects tampering and refuses local mode in production',()=>{
  process.env.APP_ENV='development';process.env.AUTH_MODE='local';process.env.SESSION_SECRET='test-session-secret-at-least-32-characters';
  const token=makeLocalSession('staff-id');expect(readLocalSession(token)).toBe('staff-id');expect(readLocalSession(token+'x')).toBeNull();
  const [payload,sig]=token.split('.');const changed=Buffer.from(JSON.stringify({...JSON.parse(Buffer.from(payload,'base64url').toString()),sub:'admin'})).toString('base64url');expect(readLocalSession(changed+'.'+sig)).toBeNull();
  process.env.APP_ENV='production';expect(readLocalSession(token)).toBeNull();expect(()=>makeLocalSession('staff-id')).toThrow();
 });
});
