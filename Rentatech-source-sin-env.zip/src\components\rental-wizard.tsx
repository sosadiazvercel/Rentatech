'use client';

import {useRef,useState} from 'react';
import Link from 'next/link';
import {eventSchema,requestSchema,money,type Estimate,type RentalRequest} from '@/lib/rental';
import s from './rental.module.css';

const WOMPI_TEST_URL='https://checkout.wompi.co/l/test_VPOS_KCpVsW';

export function RentalWizard({products,model,quantity}:{products:{code:string;name:string;inventory:number}[];model:string;quantity:number}) {
 const [v,set]=useState<RentalRequest>({equipment:model,quantity:Math.max(3,Math.min(15,quantity)),days:1,date:'',start:'10:00',durationHours:8,city:'Bogota',address:'',contentStatus:'custom',name:'',company:'',email:'',phone:'',notes:'',nit:'',privacy:true});
 const [privacy,setPrivacy]=useState(false),[step,setStep]=useState(0),[quote,setQuote]=useState<Estimate|null>(null),[error,setError]=useState(''),[busy,setBusy]=useState(false),[result,setResult]=useState<{number:string;estimate?:Estimate}|null>(null);
 const key=useRef({body:'',key:''});
 const pendingManual=quote?.pending.some(p=>p.includes('cotizar')||p.includes('confirmar'))??false;

 function requestKey(){
  return globalThis.crypto?.randomUUID?.() ?? `${Date.now().toString(36)}-${Math.random().toString(36).slice(2,18)}-${Math.random().toString(36).slice(2,18)}`;
 }
 function change<K extends keyof RentalRequest>(k:K,value:RentalRequest[K]){
  set(p=>({...p,[k]:value}));
  if(['equipment','quantity','days','date','start','city','address','contentStatus'].includes(k))setQuote(null);
  setError('');
 }
 const event={equipment:v.equipment,quantity:v.quantity,days:v.days,date:v.date,start:v.start,durationHours:v.durationHours,city:v.city,address:v.address,contentStatus:v.contentStatus};
 async function price(){
  const checked=eventSchema.safeParse(event);
  if(!checked.success)throw new Error(checked.error.issues[0].message);
  const r=await fetch('/api/v1/rental/estimate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(checked.data)});
  const data=await r.json();
  if(!r.ok)throw new Error(data.error?.message);
  setQuote(data);
  if(v.quantity>data.available)throw new Error(`Solo hay ${data.available} visores disponibles para ese horario.`);
  return data;
 }
 async function next(){
  setBusy(true);setError('');
  try{
   if(step===0)await price();
   if(step===1){if(!v.address.trim())throw new Error('Escribe la direccion o el lugar previsto para el evento.');await price();}
   if(step===2){const checked=requestSchema.safeParse({...v,privacy});if(!checked.success)throw new Error(checked.error.issues[0].message);await price();}
   setStep(p=>p+1);
  }catch(e){setError(e instanceof Error?e.message:'No pudimos continuar');}
  finally{setBusy(false);}
 }
 async function submit(){
  setBusy(true);setError('');
  try{
   const body=JSON.stringify({...v,privacy});
   if(key.current.body!==body)key.current={body,key:requestKey()};
   const r=await fetch('/api/v1/rental/quotes',{method:'POST',headers:{'Content-Type':'application/json','Idempotency-Key':key.current.key},body});
   const data=await r.json();
   if(!r.ok)throw new Error(data.error?.message);
   setResult(data);
  }catch(e){setError(e instanceof Error?e.message:'No pudimos guardar la solicitud');}
  finally{setBusy(false);}
 }
 function input(k:keyof RentalRequest,label:string,type='text',max?:number){
  return <label className="field">{label}<input aria-label={label} type={type} value={String(v[k])} onChange={e=>change(k,(type==='number'?Number(e.target.value):e.target.value) as never)} min={type==='number'?1:undefined} max={max}/></label>;
 }
 function lines(q:Estimate){
  return [
   ['Visores',`${v.quantity} x ${q.equipmentName} x ${v.days} dia(s)`,q.hardware],
   ['Operador VR obligatorio','Jornada incluida hasta 8 horas',q.staff],
   ['Transporte',q.transport==null?'Fuera de Bogota: por cotizar':'Bogota ida y vuelta',q.transport],
   [q.contentLabel,v.contentStatus==='ready'?'Se cobra por proyecto':'Por definir segun experiencia',q.content],
  ];
 }
 if(result)return <section className="reading" aria-live="polite"><div className="eyebrow">Solicitud recibida</div><h1>Hemos recibido tu solicitud.</h1><p>Tu cotizacion <strong>{result.number}</strong> quedo guardada. Revisaremos disponibilidad, logistica y contenido contigo antes de confirmar la reserva.</p><div className="notice">Este envio no bloquea equipos hasta que nuestro equipo valide la disponibilidad y el pago correspondiente.</div><div className="actions" style={{marginTop:24}}><Link className="button" href={WOMPI_TEST_URL} target="_blank" rel="noreferrer">Pagar en linea</Link><button className="button secondary" onClick={()=>{setResult(null);setStep(0);key.current={body:'',key:''};}}>Nueva solicitud</button></div></section>;
 return <section className={s.wizard}>
  <ol className={s.steps} aria-label="Pasos del cotizador">{['Equipo y fecha','Lugar y contenido','Tus datos','Cotizacion'].map((label,i)=><li key={label} aria-current={step===i?'step':undefined}><span>{i+1}</span>{label}</li>)}</ol>
  <div className={s.wizardLayout}><div className="card">
   <h2 className={s.stepTitle}>{['Configura tu alquiler VR','Donde sera la experiencia?','Con quien hablamos?','Resumen de cotizacion'][step]}</h2>
   {step===0&&<div className="stack"><label className="field">Modelo de visor<select aria-label="Modelo de visor" value={v.equipment} onChange={e=>change('equipment',e.target.value)}>{products.map(p=><option key={p.code} value={p.code}>{p.name}</option>)}</select></label><div className="fields">{input('quantity','Cantidad de visores','number',15)}{input('days','Numero de dias de alquiler','number',30)}</div><small className="muted">Minimo 3 visores. Maximo inicial del cotizador: 15 visores. {quote?`${quote.available} disponibles en el horario consultado.`:`${products.find(p=>p.code===v.equipment)?.inventory??0} unidades registradas.`}</small><div className="fields">{input('date','Fecha del evento','date')}{input('start','Hora de inicio','time')}</div><p className="notice">El operador VR es obligatorio y se muestra como concepto separado. La jornada incluida es de hasta 8 horas. Hora adicional: $50.000.</p></div>}
   {step===1&&<div className="stack">{input('city','Ubicacion / ciudad')}<p className="notice">Bogota suma automaticamente $180.000 de transporte ida y vuelta. Fuera de Bogota queda como transporte por cotizar.</p>{input('address','Direccion o lugar del evento')}<fieldset className={s.inlineChoice}><legend>Ya tienes la experiencia o contenido que quieres utilizar?</legend><label><input type="radio" checked={v.contentStatus==='ready'} onChange={()=>change('contentStatus','ready')}/>Si, ya tengo contenido</label><label><input type="radio" checked={v.contentStatus==='custom'} onChange={()=>change('contentStatus','custom')}/>No, necesito experiencia personalizada</label></fieldset><label className="field">Notas del evento<textarea aria-label="Notas del evento" value={v.notes} onChange={e=>change('notes',e.target.value)} placeholder="Describe el evento, asistentes, contenido o idea de experiencia."/></label><small className="muted">Si respondes si, la configuracion se suma por proyecto. Si respondes no, el contenido queda por definir.</small></div>}
   {step===2&&<div className="stack"><div className="fields">{input('name','Nombre de contacto')}{input('company','Empresa (opcional)')}{input('email','Correo electronico','email')}{input('phone','Telefono / WhatsApp')}{input('nit','NIT (opcional)')}</div><label className="check"><input type="checkbox" checked={privacy} onChange={e=>setPrivacy(e.target.checked)}/>Acepto el aviso de privacidad y el tratamiento de mis datos para gestionar esta solicitud.</label><Link href="/politicas/privacidad">Leer aviso de privacidad</Link></div>}
   {step===3&&quote&&<div className="stack"><dl className={s.summary}><dt>Experiencia</dt><dd>{quote.equipmentName} - {v.quantity} visores</dd><dt>Fecha</dt><dd>{v.date} - {v.start} (Bogota)</dd><dt>Dias</dt><dd>{v.days}</dd><dt>Lugar</dt><dd>{v.address}, {v.city}</dd></dl><div className={s.breakdown}>{lines(quote).map(([label,description,value])=><div key={String(label)}><span><strong>{label}</strong><small>{description}</small></span><b>{value==null?'Por definir':money(Number(value))}</b></div>)}</div><div className={s.quotePrice}><small>{pendingManual?'Total estimado con pendientes':'Total estimado'}</small><strong>{money(quote.total)}</strong><span>{quote.additionalHourNote}</span></div>{quote.pending.length>0&&<div className="notice"><strong>Por revisar:</strong><ul>{quote.pending.map(p=><li key={p}>{p}</li>)}</ul></div>}<div className="actions"><Link className="button secondary" href={WOMPI_TEST_URL} target="_blank" rel="noreferrer">Pagar en linea</Link></div><small className="muted">La cotizacion no bloquea inventario. Nuestro equipo validara disponibilidad, logistica y pago antes de confirmar la reserva.</small></div>}
   {error&&<p role="alert" aria-label="Error del cotizador" className="message-error" style={{marginTop:20}}>{error}</p>}
   <div className="actions" style={{marginTop:28}}>{step>0&&<button type="button" disabled={busy} className="button secondary" onClick={()=>setStep(p=>p-1)}>Atras</button>}<button type="button" disabled={busy} className="button" onClick={step===3?submit:next}>{busy?'Consultando...':step===3?'Solicitar cotizacion':step===0?'Calcular disponibilidad':'Continuar'}</button></div>
  </div><aside className={s.wizardAside}><div className="eyebrow">Cotizador VR</div><h3>Precio cerrado cuando aplica.</h3><p>Visores por rango, operador obligatorio, transporte Bogota y configuracion de contenido se muestran discriminados.</p><p>Fuera de Bogota o contenido personalizado quedan marcados como por cotizar.</p><small>Usa tus datos de contacto reales para que podamos confirmar disponibilidad y siguiente paso.</small></aside></div>
 </section>;
}
