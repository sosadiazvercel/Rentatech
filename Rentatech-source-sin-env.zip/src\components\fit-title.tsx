'use client';

import {createElement,useEffect,useRef,useState,type ElementType,type ReactNode} from 'react';

type FitTitleProps={
 as?:ElementType;
 children:ReactNode;
 className?:string;
 max:number;
 min:number;
};

export function FitTitle({as='h1',children,className,max,min}:FitTitleProps){
 const ref=useRef<HTMLElement>(null);
 const [size,setSize]=useState(max);
 useEffect(()=>{
  const el=ref.current;
  if(!el)return;
  let frame=0;
  const fit=()=>{
   cancelAnimationFrame(frame);
   frame=requestAnimationFrame(()=>{
    el.style.fontSize=`${max}px`;
    const available=el.clientWidth;
    const needed=el.scrollWidth;
    const next=available&&needed>available?Math.max(min,Math.floor(max*(available/needed))-1):max;
    setSize(next);
   });
  };
  fit();
  const ro=new ResizeObserver(fit);
  ro.observe(el);
  return ()=>{cancelAnimationFrame(frame);ro.disconnect();};
 },[children,max,min]);
 return createElement(as,{ref,className,style:{fontSize:`${size}px`}},children);
}
