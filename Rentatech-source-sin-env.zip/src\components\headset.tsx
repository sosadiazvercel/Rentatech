import Image from 'next/image';

export function Headset({model='QUEST3'}:{model?:string}) {
 const version=model==='QUEST2'?'2':'3';
 return <Image src={`/images/meta-quest-${version}.jpg`} alt={`Fotografía de referencia de Meta Quest ${version} con sus controles; no corresponde al inventario de RENTATECH`} width={1200} height={800} sizes="(max-width: 760px) 100vw, 560px" style={{display:'block',width:'100%',height:'auto'}}/>;
}
