import type {Metadata} from 'next';
import Link from 'next/link';
import {ProductCards} from '@/components/marketing';
import {getPublicProducts} from '@/server/public-products';
import s from '@/components/marketing.module.css';

export const dynamic='force-dynamic';
export const metadata:Metadata={title:'Realidad virtual'};

export default async function VR(){
 const products=await getPublicProducts();
 return <div className="wrap">
  <div className={s.categoryHead}>
   <div>
    <p className="breadcrumb">Equipos / Realidad virtual</p>
    <h1>Realidad Virtual</h1>
   </div>
   <p>Equipos Meta listos para eventos y experiencias inmersivas. Renta tecnologia de ultima generacion, sin complicaciones.</p>
  </div>
  <div className={s.categoryLayout}>
   <aside className={s.filters} aria-label="Explorar">
    <p>Explorar</p>
    <Link href="/vr" aria-current="page">Todos</Link>
    {products.map(p=><Link key={p.code} href={p.href}>{p.title}</Link>)}
   </aside>
   <ProductCards products={products}/>
  </div>
 </div>;
}
