import Link from 'next/link';
import {FitTitle} from './fit-title';
import {Headset} from './headset';
import type {PublicProduct} from '@/server/public-products';
import s from './marketing.module.css';

export function ProductCards({products}:{products:PublicProduct[]}){return <div className={s.catalogGrid}>{products.map(p=><article key={p.code} className={s.productTile}>
 <Link className={`${s.productPhoto} product-image-frame`} href={p.href} aria-label={`Ver ${p.title}`}>
  <Headset model={p.code}/>
 </Link>
 <div className={s.productInfo}>
  <p>{p.meta}</p>
  <FitTitle as="h3" className={s.productTitle} max={28} min={13}>{p.title}</FitTitle>
  <p>{p.text}</p>
  <div className={s.productActions}>
   <div><strong>{p.price}</strong><span>/ dia</span></div>
   <Link className="button compact" href={`/cotizar?equipo=${p.code}`}>Solicitar cotizacion</Link>
  </div>
 </div>
 </article>)}</div>;}

export function Closing(){return <section className={s.simpleClosing}>
 <h2>Cuéntanos que necesitas rentar.</h2>
 <Link className="button" href="/cotizar">Solicitar cotizacion</Link>
</section>;}
